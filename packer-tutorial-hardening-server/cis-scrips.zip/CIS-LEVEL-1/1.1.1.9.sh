#!/bin/bash
# 1.1.1.9 Ensure usb-storage kernel module is not available

echo "========================================"
echo "Vulnerability: 1.1.1.9 Ensure usb-storage kernel module is not available"
echo "========================================"

MOD_CONF="/etc/modprobe.d/usb-storage.conf"

# Step 1: Check if usb-storage module is loaded
echo "[*] Checking if usb-storage module is loaded..."
lsmod | grep usb_storage

# Step 2: Remediate
echo "[*] Disabling usb-storage module..."
sudo tee $MOD_CONF > /dev/null <<EOF
install usb-storage /bin/false
blacklist usb-storage
EOF

# Optionally unload the module immediately if it is loaded
if lsmod | grep -q usb_storage; then
    echo "[*] Unloading usb-storage module..."
    sudo modprobe -r usb_storage
fi

# Step 3: Verify again
echo "[*] Verifying usb-storage module is disabled..."
lsmod | grep usb_storage || echo "usb-storage module is not loaded."

echo "========================================"
echo "usb-storage module disabled successfully."
echo
