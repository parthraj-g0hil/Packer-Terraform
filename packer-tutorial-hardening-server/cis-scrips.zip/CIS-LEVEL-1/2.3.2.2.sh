#!/bin/bash

echo "========================================"
echo "Vulnerability: 2.3.2.2 Ensure systemd-timesyncd is enabled and running"
echo "========================================"

# Step 1: Check
echo "[*] Checking if systemd-timesyncd is enabled..."
enabled=$(systemctl is-enabled systemd-timesyncd.service 2>/dev/null)

echo "[*] Checking if systemd-timesyncd is active..."
active=$(systemctl is-active systemd-timesyncd.service 2>/dev/null)

echo "[*] Checking time synchronization status..."
sync_status=$(timedatectl status | grep -E "synchronized|NTP")

if [[ "$enabled" == "enabled" && "$active" == "active" && "$sync_status" == *"yes"* ]]; then
    echo "✅ systemd-timesyncd is enabled, running, and time is synchronized."
else
    echo "❌ systemd-timesyncd is not fully compliant. Applying remediation..."

    # Step 2: Remediate
    echo "[*] Unmasking service (if masked)..."
    sudo systemctl unmask systemd-timesyncd.service

    echo "[*] Enabling and starting service..."
    sudo systemctl --now enable systemd-timesyncd.service

    # Step 3: Verify
    echo "[*] Verifying again..."
    enabled=$(systemctl is-enabled systemd-timesyncd.service 2>/dev/null)
    active=$(systemctl is-active systemd-timesyncd.service 2>/dev/null)
    sync_status=$(timedatectl status | grep -E "synchronized|NTP")

    if [[ "$enabled" == "enabled" && "$active" == "active" && "$sync_status" == *"yes"* ]]; then
        echo "✅ Remediation successful: systemd-timesyncd is enabled, running, and time is synchronized."
    else
        echo "❌ Remediation failed. Please check manually."
    fi
fi

echo "========================================"
echo