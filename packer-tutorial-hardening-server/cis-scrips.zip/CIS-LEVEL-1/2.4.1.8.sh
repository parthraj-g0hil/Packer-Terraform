#!/bin/bash
# 2.4.1.8 Ensure crontab is restricted to authorized users

echo "========================================"
echo "Vulnerability: 2.4.1.8 Ensure crontab is restricted to authorized users"
echo "========================================"

CRON_ALLOW="/etc/cron.allow"

# Step 1: Check if cron is installed and crontab restrictions
echo "[*] Checking cron installation and crontab restrictions..."
dpkg -l | grep cron
ls -l $CRON_ALLOW 2>/dev/null

# Step 2: Remediate
echo "[*] Restricting crontab access to root only..."
sudo bash -c "echo 'root' > $CRON_ALLOW"

# Set correct permissions
sudo chmod 640 $CRON_ALLOW

# Set ownership based on crontab group
if getent group crontab >/dev/null; then
    sudo chown root:crontab $CRON_ALLOW
else
    sudo chown root:root $CRON_ALLOW
fi

# Step 3: Verify again
echo "[*] Verifying crontab access restrictions..."
ls -l $CRON_ALLOW
cat $CRON_ALLOW

echo "========================================"
echo "Crontab restricted to authorized users successfully."
echo
