#!/bin/bash


echo "========================================"
echo "Vulnerability: 3.3.2 Ensure packet redirect sending is disabled"
echo "========================================"

# Step 1: Check current settings
echo "[*] Checking current send_redirects settings..."
sysctl net.ipv4.conf.all.send_redirects
sysctl net.ipv4.conf.default.send_redirects

echo "[*] Checking all interfaces..."
for iface in $(ls /proc/sys/net/ipv4/conf/); do
    echo -n "$iface: "; cat /proc/sys/net/ipv4/conf/$iface/send_redirects
done

# Step 2: Remediate
echo "[*] Applying remediation: disabling send_redirects..."

sudo tee /etc/sysctl.d/60-disable-redirects.conf > /dev/null <<EOF
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0
EOF

sudo sysctl -w net.ipv4.conf.all.send_redirects=0
sudo sysctl -w net.ipv4.conf.default.send_redirects=0
sudo sysctl -w net.ipv4.route.flush=1

for iface in $(ls /proc/sys/net/ipv4/conf/); do
    sudo sysctl -w net.ipv4.conf.$iface.send_redirects=0
done

# Step 3: Verify again
echo "[*] Verifying remediation..."
sysctl net.ipv4.conf.all.send_redirects
sysctl net.ipv4.conf.default.send_redirects

echo "[*] Checking all interfaces again..."
for iface in $(ls /proc/sys/net/ipv4/conf/); do
    echo -n "$iface: "; cat /proc/sys/net/ipv4/conf/$iface/send_redirects
done

echo "========================================"
echo