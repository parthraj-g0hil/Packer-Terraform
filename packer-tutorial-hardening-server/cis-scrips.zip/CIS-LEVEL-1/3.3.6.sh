#!/bin/bash
# 3.3.6 Ensure secure ICMP redirects are not accepted

echo "========================================"
echo "Vulnerability: 3.3.6 Ensure secure ICMP redirects are not accepted"
echo "========================================"

SYSCTL_CONF="/etc/sysctl.d/60-netipv4-secure-redirects.conf"

# Step 1: Check current secure_redirects settings
echo "[*] Checking current secure_redirects values..."
sysctl net.ipv4.conf.all.secure_redirects
sysctl net.ipv4.conf.default.secure_redirects

# Step 2: Remediate
echo "[*] Disabling secure ICMP redirects..."
sudo tee $SYSCTL_CONF > /dev/null <<EOF
net.ipv4.conf.all.secure_redirects = 0
net.ipv4.conf.default.secure_redirects = 0
EOF

# Apply the settings immediately
sudo sysctl -w net.ipv4.conf.all.secure_redirects=0
sudo sysctl -w net.ipv4.conf.default.secure_redirects=0
sudo sysctl --system

# Step 3: Verify again
echo "[*] Verifying secure_redirects settings..."
sysctl net.ipv4.conf.all.secure_redirects
sysctl net.ipv4.conf.default.secure_redirects

echo "========================================"
echo "Secure ICMP redirects disabled successfully."
echo
