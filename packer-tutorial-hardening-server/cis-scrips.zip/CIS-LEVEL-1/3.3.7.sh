#!/bin/bash
# 3.3.7 Ensure reverse path filtering is enabled

echo "========================================"
echo "Vulnerability: 3.3.7 Ensure reverse path filtering is enabled"
echo "========================================"

# Step 1: Check current rp_filter settings
echo "[*] Checking current rp_filter settings..."
sysctl net.ipv4.conf.all.rp_filter
sysctl net.ipv4.conf.default.rp_filter

echo "[*] Checking all interfaces..."
for iface in $(ls /proc/sys/net/ipv4/conf/); do
    echo "$iface: $(cat /proc/sys/net/ipv4/conf/$iface/rp_filter)"
done

# Step 2: Remediate
echo "[*] Enabling reverse path filtering..."
# Enable for all interfaces immediately
sudo sysctl -w net.ipv4.conf.all.rp_filter=1
sudo sysctl -w net.ipv4.conf.default.rp_filter=1
for iface in $(ls /proc/sys/net/ipv4/conf/); do
    sudo sysctl -w net.ipv4.conf.$iface.rp_filter=1
done
sudo sysctl -w net.ipv4.route.flush=1

# Persist changes via sysctl.d
echo "[*] Writing persistent configuration..."
sudo tee /etc/sysctl.d/60-netipv4-rpfilter.conf > /dev/null <<EOF
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1
EOF
for iface in $(ls /proc/sys/net/ipv4/conf/); do
    echo "net.ipv4.conf.$iface.rp_filter = 1" | sudo tee -a /etc/sysctl.d/60-netipv4-rpfilter.conf > /dev/null
done

# Apply persistent settings
sudo sysctl --system

# Step 3: Verify again
echo "[*] Verifying rp_filter settings..."
sysctl net.ipv4.conf.all.rp_filter
sysctl net.ipv4.conf.default.rp_filter
for iface in $(ls /proc/sys/net/ipv4/conf/); do
    echo "$iface: $(cat /proc/sys/net/ipv4/conf/$iface/rp_filter)"
done

echo "========================================"
echo
