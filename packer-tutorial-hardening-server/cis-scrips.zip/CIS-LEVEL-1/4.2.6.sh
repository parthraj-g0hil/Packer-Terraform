#!/bin/bash
set -euo pipefail

echo "========================================"
echo "Vulnerability: 4.2.6 Ensure UFW firewall rules exist for all open ports"
echo "========================================"

# Step 1: Reset and enable UFW
echo "[*] Resetting UFW..."
ufw --force reset
echo "[*] Enabling UFW..."
ufw --force enable

# Step 2: Always allow SSH (port 22)
echo "[*] Allowing SSH..."
ufw allow in 22/tcp comment 'Allow SSH'

# Step 3: Detect open ports
echo "[*] Detecting open listening ports..."
open_ports=$(ss -tuln | awk 'NR>1 {print $5}' | awk -F: '{print $NF}' | sort -u | grep -E '^[0-9]+$' || true)

if [[ -z "$open_ports" ]]; then
  echo "[*] No open ports detected."
else
  echo "[*] Found open ports: $open_ports"
  for port in $open_ports; do
    if [[ "$port" -eq 22 ]]; then
      echo "[*] Skipping port 22 (already allowed)"
      continue
    fi
    echo "[*] Denying port $port (not explicitly allowed)..."
    ufw deny in "$port" comment "Deny inbound traffic on port $port"
  done
fi

# Step 4: Reload and show status
echo "[*] Reloading UFW..."
ufw reload

echo "[*] Final UFW status:"
ufw status verbose

echo "========================================"
echo "CIS-compliant UFW firewall rules applied."
echo "========================================"
