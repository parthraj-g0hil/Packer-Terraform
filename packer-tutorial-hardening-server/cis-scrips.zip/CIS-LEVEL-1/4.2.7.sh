#!/bin/bash
set -euo pipefail

echo "========================================"
echo "Vulnerability: 4.2.7 Ensure UFW default deny firewall policy"
echo "========================================"

# Step 1: Ensure UFW is installed
if ! command -v ufw >/dev/null 2>&1; then
  echo "[*] Installing ufw..."
  apt-get install -y ufw
fi

# Step 2: Reset UFW completely
echo "[*] Resetting UFW..."
ufw --force reset

# Step 3: Set default deny policies
echo "[*] Setting default deny policies..."
ufw default deny incoming
ufw default deny outgoing
ufw default deny routed

# Step 4: Allow only SSH
echo "[*] Allowing SSH (22/tcp)..."
ufw allow in 22/tcp
ufw allow out 22/tcp

# Step 5: Enable logging
echo "[*] Enabling UFW logging..."
ufw logging on

# Step 6: Enable UFW (auto-confirm)
echo "[*] Enabling UFW..."
ufw --force enable

# Step 7: Reload and verify
echo "[*] Reloading UFW..."
ufw reload

echo "[*] Verifying UFW configuration..."
ufw status verbose

echo "========================================"
echo "CIS-compliant UFW setup completed (only SSH open)."
echo "========================================"
