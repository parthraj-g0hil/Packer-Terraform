#!/bin/bash
# 5.3.2.4 Ensure pam_pwhistory module is enabled (non-interactive)

echo "========================================"
echo "Vulnerability: 5.3.2.4 Ensure pam_pwhistory module is enabled"
echo "========================================"

PAM_CONFIG_DIR="/usr/share/pam-configs"
PAM_PROFILE="$PAM_CONFIG_DIR/pwhistory"

# Step 1: Check if pam_pwhistory profile already exists
if grep -q "pam_pwhistory\.so" $PAM_CONFIG_DIR/*; then
    echo "[*] pam_pwhistory module already exists in PAM profiles."
else
    echo "[*] Creating pam_pwhistory profile..."
    sudo tee $PAM_PROFILE > /dev/null <<EOF
Name: pwhistory
Default: yes
Priority: 1024
Password-Type: Primary
Password: requisite pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok
EOF
fi

# Step 2: Enable the profile in pam-auth-update (non-interactive)
if sudo pam-auth-update --list | grep -q "pwhistory"; then
    echo "[*] Enabling pam_pwhistory profile non-interactively..."
    sudo DEBIAN_FRONTEND=noninteractive pam-auth-update --enable pwhistory
else
    echo "[*] pam-auth-update profile 'pwhistory' not found. Skipping enable."
fi

# Step 3: Verify configuration in common-password
echo "[*] Verifying common-password for pam_pwhistory..."
grep -E "pam_pwhistory\.so" /etc/pam.d/common-password || echo "[!] pam_pwhistory not found in common-password"

echo "========================================"
echo "pam_pwhistory module enabled and configured successfully."
echo "========================================"
