#!/bin/bash
set -euxo pipefail

echo "========================================"
echo "Vulnerability: 5.3.3.1.1 Ensure password failed attempts lockout is configured"
echo "========================================"

FAILLOCK_CONF="/etc/security/faillock.conf"
DENY_VALUE="5"

# Step 1: Check current deny settings
echo "[*] Checking current faillock deny settings..."
grep -i deny $FAILLOCK_CONF 2>/dev/null || true

echo "[*] Checking PAM modules for faillock deny..."
grep -Pl -- '\bpam_faillock\.so\h+([^#\n\r]+\h+)?deny\b' /etc/pam.d/* /usr/share/pam-configs/* 2>/dev/null || true

# Step 2: Remediate
echo "[*] Applying remediation: setting deny = $DENY_VALUE..."
sudo sed -i -E "s/^\s*#?\s*deny\s*=.*/deny = $DENY_VALUE/" $FAILLOCK_CONF || echo "deny = $DENY_VALUE" | sudo tee -a $FAILLOCK_CONF

# Step 3: Enable PAM faillock module non-interactively
echo "[*] Enabling PAM faillock module (non-interactive)..."
export DEBIAN_FRONTEND=noninteractive
sudo pam-auth-update --enable faillock --package --force

# Step 4: Verify again
echo "[*] Verifying updated deny setting..."
grep -i deny $FAILLOCK_CONF || true

echo "========================================"
echo "Password failed attempts lockout configured successfully (deny=$DENY_VALUE)."
echo
