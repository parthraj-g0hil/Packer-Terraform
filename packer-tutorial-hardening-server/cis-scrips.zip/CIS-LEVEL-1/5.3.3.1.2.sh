#!/bin/bash
# 5.3.3.1.2 Ensure password unlock time is configured (faillock)

echo "========================================"
echo "Vulnerability: 5.3.3.1.2 Ensure password unlock time is configured"
echo "========================================"

FAILLOCK_CONF="/etc/security/faillock.conf"
UNLOCK_VALUE="900"  # 900 seconds = 15 minutes

# Step 1: Check current unlock_time settings
echo "[*] Checking current faillock configuration..."
grep -i unlock_time $FAILLOCK_CONF 2>/dev/null

echo "[*] Checking PAM modules for unlock_time..."
grep -Pl -- '\bpam_faillock\.so\h+([^#\n\r]+\h+)?unlock_time\b' /etc/pam.d/* /usr/share/pam-configs/* 2>/dev/null

# Step 2: Remediate
echo "[*] Applying remediation: setting unlock_time and root_unlock_time..."
sudo sed -i -E "s/^\s*#?\s*unlock_time\s*=.*/unlock_time = $UNLOCK_VALUE/" $FAILLOCK_CONF || echo "unlock_time = $UNLOCK_VALUE" | sudo tee -a $FAILLOCK_CONF
sudo sed -i -E "s/^\s*#?\s*root_unlock_time\s*=.*/root_unlock_time = $UNLOCK_VALUE/" $FAILLOCK_CONF || echo "root_unlock_time = $UNLOCK_VALUE" | sudo tee -a $FAILLOCK_CONF

# Step 3: Verify again
echo "[*] Verifying updated unlock_time settings..."
grep -i unlock_time $FAILLOCK_CONF

echo "========================================"
echo "Password unlock time configured successfully (unlock_time=$UNLOCK_VALUE, root_unlock_time=$UNLOCK_VALUE)."
echo
