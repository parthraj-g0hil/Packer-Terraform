#!/bin/bash
set -euxo pipefail

echo "========================================"
echo "Vulnerability: 5.3.3.2.2 Ensure minimum password length is configured"
echo "========================================"

# Step 1: Check current minlen settings
echo "[*] Checking current minlen settings..."
grep -i minlen /etc/security/pwquality.conf || true
grep -r -i minlen /etc/security/pwquality.conf.d/ 2>/dev/null || true
grep pam_pwquality /etc/pam.d/common-password || true

# Step 2: Remediate
echo "[*] Applying remediation..."
sudo mkdir -p /etc/security/pwquality.conf.d/
echo "minlen = 14" | sudo tee /etc/security/pwquality.conf.d/50-pwlength.conf

# Comment out previous minlen in main config if exists
sudo sed -i 's/^\s*minlen\s*=/# &/' /etc/security/pwquality.conf || true

# Update PAM configuration non-interactively
echo "[*] Updating PAM configuration non-interactively..."
sudo env DEBIAN_FRONTEND=noninteractive pam-auth-update --package --force

# Step 3: Verify again
echo "[*] Verifying minlen setting..."
grep -i minlen /etc/security/pwquality.conf.d/* || true

echo "========================================"
echo "Minimum password length configured successfully."
echo
