#!/bin/bash
# 5.3.3.2.4 Ensure password same consecutive characters is configured

echo "========================================"
echo "Vulnerability: 5.3.3.2.4 Ensure password same consecutive characters is configured"
echo "========================================"

PWQUALITY_DIR="/etc/security/pwquality.conf.d/"
PWQUALITY_FILE="${PWQUALITY_DIR}50-pwrepeat.conf"
MAXREPEAT_VALUE="3"

# Step 1: Check current maxrepeat settings
echo "[*] Checking current maxrepeat settings..."
grep -i maxrepeat /etc/security/pwquality.conf 2>/dev/null
grep -r -i maxrepeat $PWQUALITY_DIR 2>/dev/null
grep pam_pwquality /etc/pam.d/common-password 2>/dev/null

# Step 2: Remediate
echo "[*] Applying remediation: setting maxrepeat = $MAXREPEAT_VALUE"
sudo mkdir -p $PWQUALITY_DIR
echo "maxrepeat = $MAXREPEAT_VALUE" | sudo tee $PWQUALITY_FILE

# Step 3: Verify again
echo "[*] Verifying maxrepeat setting..."
grep -i maxrepeat $PWQUALITY_DIR/*
# Expected output: maxrepeat = 3

echo "========================================"
echo "Password maxrepeat configured successfully."
echo
