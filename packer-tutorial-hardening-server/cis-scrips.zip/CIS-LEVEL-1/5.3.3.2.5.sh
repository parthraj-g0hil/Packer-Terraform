#!/bin/bash
set -euxo pipefail

echo "========================================"
echo "Vulnerability: 5.3.3.2.5 Ensure password maximum sequential characters is configured"
echo "========================================"

PWQUALITY_DIR="/etc/security/pwquality.conf.d/"
PWQUALITY_FILE="${PWQUALITY_DIR}50-pwmaxsequence.conf"
MAXSEQUENCE_VALUE="3"

# Step 1: Check current maxsequence settings
echo "[*] Checking current maxsequence settings..."
grep -i maxsequence $PWQUALITY_DIR/* 2>/dev/null || true

# Step 2: Remediate
echo "[*] Applying remediation: setting maxsequence = $MAXSEQUENCE_VALUE..."
sudo mkdir -p $PWQUALITY_DIR
echo "maxsequence = $MAXSEQUENCE_VALUE" | sudo tee $PWQUALITY_FILE

# Step 3: Check PAM common-password configuration
echo "[*] Checking pam_pwquality in common-password..."
grep pam_pwquality /etc/pam.d/common-password || true

# Step 4: Apply PAM configuration non-interactively
echo "[*] Updating PAM configuration non-interactively..."
sudo env DEBIAN_FRONTEND=noninteractive pam-auth-update --package --force

# Step 5: Verify again
echo "[*] Verifying maxsequence setting..."
grep -i maxsequence $PWQUALITY_DIR/* || true

echo "========================================"
echo "Password maxsequence configured successfully (maxsequence=$MAXSEQUENCE_VALUE)."
echo
