#!/bin/bash
# 5.3.3.4.1 Ensure pam_unix does not include nullok

echo "========================================"
echo "Vulnerability: 5.3.3.4.1 Ensure pam_unix does not include nullok"
echo "========================================"

# Step 1: Check for nullok usage
echo "[*] Checking for nullok in PAM configuration..."
grep -PH -- '^\s*([^#\n\r]+\s+)?pam_unix\.so\s+([^#\n\r]+\s+)?nullok\b' /etc/pam.d/* 2>/dev/null

# Step 2: Remediate
echo "[*] Removing nullok from PAM configuration files..."
for file in /etc/pam.d/common-auth /etc/pam.d/common-password /etc/pam.d/common-account /etc/pam.d/common-session; do
    if [ -f "$file" ]; then
        sudo sed -i 's/\bnullok\b//g' "$file"
    fi
done

# Step 3: Verify again
echo "[*] Verifying nullok has been removed..."
grep -PH -- '^\s*([^#\n\r]+\s+)?pam_unix\.so\s+([^#\n\r]+\s+)?nullok\b' /etc/pam.d/* || echo "nullok has been removed from all PAM files."

echo "========================================"
echo "pam_unix nullok removal completed successfully."
echo
