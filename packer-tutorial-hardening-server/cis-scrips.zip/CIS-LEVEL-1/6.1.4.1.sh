#!/bin/bash
# 6.1.4.1 Ensure access to all logfiles has been configured

echo "========================================"
echo "Vulnerability: 6.1.4.1 Ensure access to all logfiles has been configured"
echo "========================================"

# Step 1: Check for log files with incorrect permissions or ownership
echo "[*] Checking log files in /var/log for improper permissions or ownership..."
sudo find /var/log -type f \( -perm /0137 -o ! -user root -o ! -group root \) -exec ls -l {} \;

# Step 2: Remediate

echo "[*] Fixing permissions for sysstat logs..."
sudo chmod 640 /var/log/sysstat/* 2>/dev/null

echo "[*] Fixing permissions for apt logs..."
sudo chmod 640 /var/log/apt/history.log /var/log/apt/term.log 2>/dev/null
sudo chmod 640 /var/log/unattended-upgrades/* 2>/dev/null

echo "[*] Fixing ownership and permissions for special logs..."
sudo chown root:utmp /var/log/wtmp /var/log/btmp /var/log/lastlog
sudo chmod 600 /var/log/wtmp /var/log/btmp /var/log/lastlog

# Step 3: Verify again
echo "[*] Verifying log file permissions and ownership..."
sudo find /var/log -type f \( -perm /0137 -o ! -user root -o ! -group root \) -exec ls -l {} \;

echo "========================================"
echo "All log file permissions and ownership have been configured successfully."
echo
