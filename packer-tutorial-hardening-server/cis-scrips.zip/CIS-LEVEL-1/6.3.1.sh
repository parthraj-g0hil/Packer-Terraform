#!/bin/bash
set -euxo pipefail

echo "========================================"
echo "Vulnerability: 6.3.1 Ensure AIDE is installed"
echo "========================================"

# Step 1: Check if AIDE is installed
echo "[*] Checking if AIDE is installed..."
dpkg -l | grep aide || true

if ! dpkg -l | grep -q aide; then
    echo "❌ AIDE is not installed. Installing..."

    # Step 2: Install AIDE and dependencies non-interactively
    sudo env DEBIAN_FRONTEND=noninteractive apt update
    sudo env DEBIAN_FRONTEND=noninteractive apt install -y \
        -o Dpkg::Options::="--force-confold" \
        aide aide-common bsd-mailx liblockfile-bin liblockfile1 libmhash2 libnsl2 postfix ssl-cert \
        </dev/null

    # Step 3: Initialize AIDE database
    echo "[*] Initializing AIDE database..."
    sudo /usr/bin/aide --init --config /etc/aide/aide.conf
    sudo mv /var/lib/aide/aide.db.new /var/lib/aide/aide.db

    # Step 4: Create daily AIDE check cron job
    echo "[*] Creating daily AIDE check cron job..."
    echo "0 5 * * * root /usr/bin/aide --check --config /etc/aide/aide.conf" | sudo tee /etc/cron.d/aide-check

else
    echo "✅ AIDE is already installed"
fi

# Step 5: Verify installation
echo "[*] Verifying AIDE installation..."
dpkg -l | grep aide || true
sudo /usr/bin/aide --check --config /etc/aide/aide.conf || true

echo "========================================"
echo "AIDE installation and initial check completed."
echo
