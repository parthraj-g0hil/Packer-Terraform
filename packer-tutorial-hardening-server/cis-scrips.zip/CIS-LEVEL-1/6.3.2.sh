#!/bin/bash
# 6.3.2 Ensure filesystem integrity is regularly checked

echo "========================================"
echo "Vulnerability: 6.3.2 Ensure filesystem integrity is regularly checked"
echo "========================================"

# Step 1: Check if AIDE is installed
echo "[*] Checking if AIDE is installed..."
dpkg -l | grep aide || echo "[!] AIDE not installed"

# Step 2: Remediate
echo "[*] Installing AIDE and enabling daily checks..."
sudo apt install -y aide aide-common

# Unmask and enable daily AIDE systemd timer
sudo systemctl unmask dailyaidecheck.timer dailyaidecheck.service
sudo systemctl --now enable dailyaidecheck.timer

# Step 3: Verify again
echo "[*] Verifying daily AIDE filesystem integrity check..."
systemctl status dailyaidecheck.timer --no-pager
systemctl list-timers | grep aide

echo "========================================"
echo "Filesystem integrity check configured successfully."
echo
